/*
 * File Name: exeBmain.cpp
 * Assignment: Lab 2 Exercise B
 * Lab Section: B02
 * Completed by: Dieter Banaag
 * Submission Date: October 1, 2023
 */

#include <iostream>
#include "graphicsworld.h"

int main()
{
    GraphicsWorld GW;
    GW.run();
    return 0;
}