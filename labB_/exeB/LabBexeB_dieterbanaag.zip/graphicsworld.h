/*
 * File Name: graphicsworld.h
 * Assignment: Lab 2 Exercise B
 * Lab Section: B02
 * Completed by: Dieter Banaag
 * Submission Date: October 1, 2023
 */

#ifndef GRAPHICSWORLD_H
#define GRAPHICSWORLD_H

class GraphicsWorld
{
public:
    void run();
};

#endif
